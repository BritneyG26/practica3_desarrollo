from flask_marshmallow import Marshmallow
from marshmallow import fields, validate, ValidationError
from ..extensions import ma


class LoginSchema(ma.Schema):
    email =fields.Email(required=True)
    password = fields.Str(required=True)
    
    class Meta:
        fields = ('email', 'password')


login_schema = LoginSchema()