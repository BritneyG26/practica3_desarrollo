from flask_marshmallow import Marshmallow
from marshmallow import fields, validate, ValidationError
from ..extensions import ma

class UsuarioSchema(ma.Schema):
    id= fields.Int(dump_only=True)
    nombre = fields.Str(required=True, validate=validate.Length(min=1, max=100))
    email = fields.Email(required=True)
    password = fields.Str(load_only=True, required=True, validate=validate.Length(min=3))
    created_at= fields.DateTime(dump_only=True)
    
    class Meta:
        fields = ('id', 'nombre', 'email', 'password', 'created_at')


usuario_schema = UsuarioSchema()
usuarios_schema = UsuarioSchema(many=True)