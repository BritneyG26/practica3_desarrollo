import redis
import json
from functools import wraps
from flask import request, jsonify
from app.config import Config

redis_client = redis.from_url(Config.REDIS_URL, decode_responses=True)

def cache_key(*args, **kwargs):
    return f"cache:{request.path}:{json.dumps(request.args.to_dict(), sort_keys=True)}"

def cached(timeout=300):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            key = cache_key()
            
            try:
                cached_data = redis_client.get(key)
                if cached_data:
                    print(f"CACHE HIT {key}")
                    return jsonify(json.loads(cached_data)), 200
            except Exception as e:
                print(f"Cache error {e}")
            
            print(f"CACHE MISS {key}")
            response = f(*args, **kwargs)
            
            try:
                if isinstance(response, tuple):
                    data, status_code = response
                    response_data = data.get_json()
                else:
                    response_data = response.get_json()
                    status_code = response.status_code
                
                
                if status_code == 200:
                    redis_client.setex(key, timeout, json.dumps(response_data))
                    print(f"Guardado en caché {key}")
                
            except Exception as e:
                print(f"Error guardando en caché {e}")
            
            return response
        
        return decorated_function
    return decorator


def clear_cache(pattern="cache:*"):
    try:
        keys = redis_client.keys(pattern)
        if keys:
            redis_client.delete(*keys)
            print(f"Limpiado {len(keys)} claves del caché")
            return len(keys)
        return 0
    except Exception as e:
        print(f"Error limpiando caché {e}")
        return 0