import logging
import sys
import uuid
from flask import request, g
import structlog

def configure_logging(app):
    """Configura logging estándar + structlog en JSON."""
    log_level = getattr(logging, str(app.config.get("LOG_LEVEL", "INFO")).upper(), logging.INFO)

    # Logging clásico
    logging.basicConfig(
        level=log_level,
        format="%(message)s",
        stream=sys.stdout,
    )

    # Structlog con contextvars
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        cache_logger_on_first_use=True,
    )

    @app.before_request
    def _bind_request_context():
        request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
        g.request_id = request_id
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            method=request.method,
            path=request.path,
            remote_addr=request.headers.get("X-Forwarded-For", request.remote_addr),
        )

    @app.after_request
    def _add_request_id_header(response):
        if getattr(g, "request_id", None):
            response.headers["X-Request-ID"] = g.request_id
        # Limpia el contexto para la siguiente request
        structlog.contextvars.clear_contextvars()
        return response
