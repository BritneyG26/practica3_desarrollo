from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from ...extensions import db
from ...models.usuario import Usuario
from app.schemas import usuario_schema, usuarios_schema, login_schema
from marshmallow import ValidationError
from flasgger import swag_from

bp = Blueprint('usuarios', __name__, url_prefix='/api')

@bp.route('/usuarios', methods=['POST'])
def crear_usuario():
    """
    Crear un nuevo usuario
    ---
    tags:
      - Usuarios
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              nombre:
                type: string
              email:
                type: string
              password:
                type: string
            required:
              - nombre
              - email
              - password
    responses:
      201:
        description: Usuario creado
      400:
        description: Error de validación
    """
    try:
        data = usuario_schema.load(request.json)
    except ValidationError as err:
        return jsonify(err.messages), 400

    if Usuario.query.filter_by(email=data['email']).first():
        return jsonify({"error": "Email ya registrado"}), 400

    nuevo_usuario = Usuario(
        nombre=data['nombre'],
        email=data['email']
    )
    nuevo_usuario.set_password(data['password'])

    db.session.add(nuevo_usuario)
    db.session.commit()

    return jsonify(usuario_schema.dump(nuevo_usuario)), 201


@bp.route('/login', methods=['POST'])
def login():
    """
    Login y obtención de token
    ---
    tags:
      - Autenticación
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              email:
                type: string
              password:
                type: string
            required:
              - email
              - password
    responses:
      200:
        description: Token
      401:
        description: Credenciales inválidas
    """
    try:
        data = login_schema.load(request.json)
    except ValidationError as err:
        return jsonify(err.messages), 400

    usuario = Usuario.query.filter_by(email=data['email']).first()

    if not usuario or not usuario.check_password(data['password']):
        return jsonify({"error": "Credenciales inválidas"}), 401

    access_token = create_access_token(identity=str(usuario.id))
    return jsonify({
        "access_token": access_token,
        "user": usuario_schema.dump(usuario)
    }), 200


@bp.route('/usuarios/privado', methods=['GET'])
@jwt_required()
def privado():
    """
    Endpoint protegido
    ---
    tags:
      - Usuarios
    security:
      - Bearer: []
    responses:
      200:
        description: Acceso autorizado
      401:
        description: No autorizado
    """
    current_user_id = int(get_jwt_identity())
    usuario = Usuario.query.get(current_user_id)
    return jsonify({
        "msg": "Acceso autorizado",
        "user": usuario_schema.dump(usuario)
    }), 200


@bp.route('/usuarios', methods=['GET'])
@jwt_required()
def listar_usuarios():
    """
    Listar todos los usuarios
    ---
    tags:
      - Usuarios
    security:
      - Bearer: []
    responses:
      200:
        description: Lista de usuarios
    """
    usuarios = Usuario.query.all()
    return jsonify(usuarios_schema.dump(usuarios)), 200


@bp.route('/usuarios/<int:id>', methods=['GET'])
@jwt_required()
def obtener_usuario(id):
    """
    Obtener un usuario por ID
    ---
    tags:
      - Usuarios
    security:
      - Bearer: []
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    responses:
      200:
        description: Usuario encontrado
      404:
        description: Usuario no encontrado
    """
    usuario = Usuario.query.get_or_404(id)
    return jsonify(usuario_schema.dump(usuario)), 200

@bp.route('/usuarios/<int:id>', methods=['DELETE'])
@jwt_required()
def eliminar_usuario(id):
    """
    Eliminar un usuario
    ---
    tags:
      - Usuarios
    security:
      - Bearer: []
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    responses:
      200:
        description: Usuario eliminado
      404:
        description: Usuario no encontrado
    """
    usuario = Usuario.query.get_or_404(id)
    db.session.delete(usuario)
    db.session.commit()
    return jsonify({"msg": "Usuario eliminado"}), 200