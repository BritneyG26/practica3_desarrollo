from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from ...extensions import db
from ...models.producto import Producto
from app.schemas import producto_schema, productos_schema
from marshmallow import ValidationError
from flasgger import swag_from

bp = Blueprint('productos', __name__, url_prefix='/api')

@bp.route('/productos', methods=['POST'])
@jwt_required()
def crear_producto():
    """
    Crear un nuevo producto
    ---
    tags:
      - Productos
    security:
      - Bearer: []
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              nombre:
                type: string
              descripcion:
                type: string
              precio:
                type: number
              stock:
                type: integer
              usuario_id:
                type: integer
            required: [nombre, descripcion, precio, stock, usuario_id]
    responses:
      201:
        description: Producto creado
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Producto'
      400:
        description: Error de validación
    """
    try:
        data = producto_schema.load(request.get_json())
    except ValidationError as err:
        return jsonify(err.messages), 400

    current_user_id = get_jwt_identity()
    data['usuario_id'] = current_user_id

    nuevo_producto = Producto(**data)
    db.session.add(nuevo_producto)
    db.session.commit()

    return jsonify(producto_schema.dump(nuevo_producto)), 201


@bp.route('/productos', methods=['GET'])
def listar_productos():
    """
    Listar todos los productos
    ---
    tags:
      - Productos
    responses:
      200:
        description: Lista de productos
        content:
          application/json:
            schema:
              type: array
              items:
                $ref: '#/components/schemas/Producto'
    """
    productos = Producto.query.all()
    return jsonify(productos_schema.dump(productos)), 200


@bp.route('/productos/<int:id>', methods=['GET'])
def obtener_producto(id):
    """
    Obtener un producto por ID
    ---
    tags:
      - Productos
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    responses:
      200:
        description: Producto encontrado
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Producto'
      404:
        description: Producto no encontrado
    """
    producto = Producto.query.get_or_404(id)
    return jsonify(producto_schema.dump(producto)), 200


@bp.route('/productos/<int:id>', methods=['PUT'])
@jwt_required()
def actualizar_producto(id):
    """
    Actualizar un producto
    ---
    tags:
      - Productos
    security:
      - Bearer: []
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              nombre:
                type: string
              descripcion:
                type: string
              precio:
                type: number
              stock:
                type: integer
    responses:
      200:
        description: Producto actualizado
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Producto'
      400:
        description: Error de validación
      404:
        description: Producto no encontrado
    """
    producto = Producto.query.get_or_404(id)

    try:
        data = producto_schema.load(request.get_json(), partial=True)
    except ValidationError as err:
        return jsonify(err.messages), 400

    for key, value in data.items():
        setattr(producto, key, value)

    db.session.commit()
    return jsonify(producto_schema.dump(producto)), 200


@bp.route('/productos/<int:id>', methods=['DELETE'])
@jwt_required()
def eliminar_producto(id):
    """
    Eliminar un producto
    ---
    tags:
      - Productos
    security:
      - Bearer: []
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: integer
    responses:
      200:
        description: Producto eliminado
      404:
        description: Producto no encontrado
    """
    producto = Producto.query.get_or_404(id)
    db.session.delete(producto)
    db.session.commit()
    return jsonify({"msg": "Producto eliminado"}), 200