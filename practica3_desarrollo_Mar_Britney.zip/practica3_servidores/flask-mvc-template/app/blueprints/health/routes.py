from flask import jsonify
from . import bp

@bp.get("/live")
def live():
    """
    Liveness probe.
    ---
    tags:
      - health
    responses:
      200:
        description: OK
    """
    return jsonify({"status": "alive"}), 200


@bp.get("/ready")
def ready():
    """
    Readiness probe.
    ---
    tags:
      - health
    responses:
      200:
        description: OK
    """
    return jsonify({"status": "ready"}), 200
