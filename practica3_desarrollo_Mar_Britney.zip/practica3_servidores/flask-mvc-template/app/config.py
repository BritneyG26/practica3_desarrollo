import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY =os.getenv('SECRET_KEY', 'dev-secret-key')
    
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'jwt-dev-secret')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    JWT_COOKIE_CSRF_PROTECT = False 
    
    SQLALCHEMY_DATABASE_URI = 'postgresql://practica_user:1234@localhost:5432/practica2'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True
    
    #anexo 1
    SQLALCHEMY_ENGINE_OPTIONS= {
        'pool_size': 10,
        'pool_recycle': 3600,
        'pool_pre_ping': True,
        'max_overflow': 20,
        'echo_pool': True
    }
    
    REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    SESSION_COOKIE_SECURE= True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'