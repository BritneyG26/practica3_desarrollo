document.addEventListener("DOMContentLoaded", function () {
  // Pequeño efecto al enviar el formulario de login
  const form = document.querySelector("form.form");
  if (form) {
    form.addEventListener("submit", () => {
      form.classList.add("loading");
    });
  }
});
