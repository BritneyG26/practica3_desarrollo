import pytest
from app import create_app
from app.extensions import db
from app.models.usuario import Usuario

@pytest.fixture()
def app():
    app = create_app("testing")
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture()
def client(app):
    return app.test_client()

@pytest.fixture()
def user(app):
    with app.app_context():
        u = Usuario(nombre="admin", email="admin@example.com")
        u.set_password("admin123")
        db.session.add(u)
        db.session.commit()
        return u
