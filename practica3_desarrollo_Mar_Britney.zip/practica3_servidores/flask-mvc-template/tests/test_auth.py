def test_api_login_success(client, user):
    resp = client.post("/auth/api/v1/auth/login", json={"email": "admin@example.com", "password": "admin123"})
    assert resp.status_code == 200
    assert resp.json["user"]["nombre"] == "admin"

def test_api_login_wrong_password(client, user):
    resp = client.post("/auth/api/v1/auth/login", json={"email": "admin@example.com", "password": "bad"})
    assert resp.status_code == 401

def test_view_login_success(client, user):
    resp = client.post("/auth/login", data={"email": "admin@example.com", "password": "admin123"}, follow_redirects=True)
    assert resp.status_code == 200
    assert b"Bienvenido" in resp.data
