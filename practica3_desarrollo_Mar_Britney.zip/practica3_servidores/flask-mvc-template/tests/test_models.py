from app.models.usuario import Usuario

def test_password_hashing(app):
    u = Usuario(nombre="u1", email="u1@example.com")
    u.set_password("secret")
    assert u.check_password("secret")
    assert not u.check_password("wrong")
